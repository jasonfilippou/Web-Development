// Using Javascript. Create an array of 10 random integer numbers between 1 - 1000 and use console.log() to display each of the numbers in the array and the sum of the array.
function getRandomInt(upper) {
    return Math.floor(Math.random() * upper);
}

let array = Array.from({length:10}, (_)=>getRandomInt(1000) + 1);

console.log(array);
console.log(array.reduce((partial, x) => partial + x, 0));
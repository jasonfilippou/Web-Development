// Go to https://www.joget.com/, use Javascript or jQuery to make the nav bar disappear. Send us the code.
document.getElementsByClassName("unite-header")[0].style.display = "hidden";

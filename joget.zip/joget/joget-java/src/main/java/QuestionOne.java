import java.util.*;
import java.util.stream.Collectors;

public class QuestionOne {

    public static void main(String[] args){
        //Variable “arrayA” is a string array of car brands: ["Honda", "Toyota", "Proton"]
        String[] arrayA = {"Honda", "Toyota", "Proton"};

        //Add "Nissan" to it. Print it out.
        arrayA = appendToArray(arrayA, "Nissan");
        System.out.println(Arrays.toString(arrayA));

        //Add "Mazda" as the first element within the string array. Print it out.
        arrayA = prependToArray(arrayA, "Mazda");
        System.out.println(Arrays.toString(arrayA));

        //Now make a new variable “arrayB” which is a string array of animals. Combine both arrays into variable “arrayA”. Print it out.
        String[] arrayB = {"Fox", "Panda", "Cat", "Dog", "Canary"};
        arrayA = combine(arrayA, arrayB);
        System.out.println(Arrays.toString(arrayA));

        //Variable “mapC” & “mapD” are both separate Map[String, String] objects of employee IDs and employee names, where:
        //mapC → ["123": "Justin",  "456": "Owen", "789": "Hugo"]
        //mapD → ["123": "George", "555":"Jack", "888": "Julian"]
        Map<String, String> mapC = new java.util.HashMap<>(Map.of("123", "Justin", "456", "Owen", "789", "Hugo")); // Have to wrap with HashMap to make the instance mutable.
        Map<String, String> mapD = Map.of("123", "George", "555", "Jack", "888", "Julian");

        //Combine them both into the variable “mapC” and print it out.
        mapC.putAll(mapD);
        System.out.println(mapC);

        // Print out the reason why the result no longer has the value "Justin"?
        System.out.println("mapC no longer contains \"Justin\" as a value because the associated key \"123\" now maps to: " + mapC.get("123"));

        //Return values in “mapC” where key contains "5"
        System.out.println(valuesWhereKeyContains(mapC, "5"));

        //Remove map entries where the value contains the "o" character in “mapC”. (ignore case)
        removeEntriesFromMap(mapC, "o");
        System.out.println(mapC);

        //I have a string variable “str” of "111222888222555". Reverse this string and assign it back to variable “str”. Print it out.
        String str = "111222888222555";
        str = reverseStringWithStringBuilder(str);
        System.out.println(str);

        //Then, replace the last occurrence of "222" in variable “str”  with "aaa" and assign it back to variable “str”. Print it out.
        str = replaceLastOccurrenceOf(str, "222", "aaa");
        System.out.println(str);
    }

    private static String[] appendToArray(String[] array, String obj){
        // If we wanted to do this naively, it would look like:

        /*
        String[] temp = new String[array.length + 1];
        for(int i = 0; i < array.length; i++){ // Even this loop can be replaced with a System.arrayCopy()
            temp[i] = array[i];
        }
        temp[temp.length - 1] = obj;
        return temp;
        */

        // Instead, we will leverage the Collections framework for cleaner and more robust code.
        List<String> intermediate =  new ArrayList<>(Arrays.asList(array));
        intermediate.add(obj);
        return intermediate.toArray(new String[0]);
    }

    private static String[] prependToArray(String[] array, String obj){
        List<String> intermediate =  new ArrayList<>(Arrays.asList(array));
        intermediate.add(0, obj);
        return intermediate.toArray(new String[0]);
    }

    private static String[] combine(String[] arrayOne, String[] arrayTwo){
        List<String> intermediateOne = new ArrayList<>(java.util.List.of(arrayOne));
        List<String> intermediateTwo = new ArrayList<>(java.util.List.of(arrayTwo));
        intermediateOne.addAll(intermediateTwo);
        return intermediateOne.toArray(new String[0]);
    }

    private static List<String> valuesWhereKeyContains(Map<String, String> map, String needle){
        Set<String> keySet = map.keySet().stream().filter(key->key.contains(needle)).collect(Collectors.toSet());
        List<String> values = new ArrayList<>();
        keySet.forEach(key->values.add(map.get(key)));
        return values;
    }

    private static void removeEntriesFromMap(Map<String, String> map, String needle){
        Set<String> keysToRemove = map.entrySet().stream().filter(entry->entry.getValue().
                toLowerCase().contains(needle.toLowerCase())).map(Map.Entry::getKey).collect(Collectors.toSet());
        keysToRemove.forEach(map::remove);
    }

    private static String reverseStringWithStringBuilder(String str){
        StringBuilder stringBuilder = new StringBuilder();
        for(int i = 0; i < str.length(); i++){
            stringBuilder.insert(0, str.charAt(i));
        }
        return stringBuilder.toString();
    }

    private static String replaceLastOccurrenceOf(String str, String substringToReplace, String substringToReplaceWith){
        int lastIndexOf = str.lastIndexOf(substringToReplace);
        return str.substring(0, lastIndexOf) + substringToReplaceWith + str.substring(lastIndexOf + substringToReplace.length());
    }
}

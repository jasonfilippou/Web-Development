public class QuestionTwo {

    public static void main(String[] args){
        int valTwoPrev = 1, valPrev = 2;
        System.out.println(valTwoPrev);
        System.out.println(valPrev);
        int i = 2;
        while(i < 7){
            int currVal = (i % 2 == 0) ? valTwoPrev * valPrev : valTwoPrev + valPrev;
            System.out.println(currVal);
            valTwoPrev = valPrev;
            valPrev = currVal;
            i++;
        }
    }
}
